def saludar(nombre):
    return "Hola " + nombre + ", este es mi primer paquete pip!" #metodo de Echo
#en la terminal
#> python3 setup.py bdist_wheel sdist "estas son las instrucciones para crear el paquete que necesito"