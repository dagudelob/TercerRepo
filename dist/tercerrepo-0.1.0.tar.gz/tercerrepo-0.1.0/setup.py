from setuptools import setup, find_packages

setup(
    name="TercerRepo",                              # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="agudelo David",                         # nombre
    author_email="agudelo.david@hotmail.com",       # correo electrónico
    url="https://github.com/dagudelob/TercerRepo",  # URL del proyecto
    )